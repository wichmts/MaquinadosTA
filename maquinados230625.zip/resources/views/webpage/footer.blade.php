<div class="section-nine mx-0 px-0 px-md-5" >
    <div class="row img-representante px-2 px-md-5 d-flex align-items-center text-center" >
        <div class="col-md-4 col-12">
            <h4 class="my-1 text-white">Atención a representantes</h4>
            <h4 class="my-1 text-white">Atención a pacientes</h4>
            <h4 class="my-1 text-white">Atención a médicos</h4>
        </div>
        <div class="col-md-4 col-12">
            <h4 class="my-1 text-white">Contacto:</h4>
            <h4 class="my-1 text-white">contacto@smmedicall.com</h4>
            <h4 class="my-1 text-white">Monterrey, N.L. México.</h4>
        </div>
        <div class="col-md-4 col-12 mb-4">
            <a href=""><h4 class="mt-1 mb-4 text-white">Aviso de privacidad.</h4></a>
            <a href="https://www.facebook.com/profile.php?id=61550338972584" target="_blank"><img src="/paper/img/facebook.png" width="40px" height="40px" class="mr-4"></a>
            <a href="https://www.linkedin.com/company/98716074/admin/feed/posts/" target="_blank"><img src="/paper/img/linkedin.png" width="40px" height="40px" class="mr-4"></a>
            <a href="https://www.instagram.com/sm.medicall/?igshid=OGQ5ZDc2ODk2ZA%3D%3D" target="_blank"><img src="/paper/img/instagram.png" width="40px" height="40px"></a>
        </div>
    </div>
</div> 