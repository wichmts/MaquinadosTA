{{-- <footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
        <div class="row">
            <nav class="footer-nav">
                <ul>
                    <li style="color: grey">
                        Conectando destinos, facilitando negocios. 
                    </li>
                </ul>
            </nav>
            <div class="credits ml-auto">
                <span class="copyright">
                    © 2025
                </span>
            </div>
        </div>
    </div>
</footer> --}}
