@include('layouts.navbars.navs.guest')

<div class="wrapper wrapper-full-page" >
    <div class="">
         
        @yield('content')
        {{-- @include('layouts.footer') --}}
    </div>
</div>
