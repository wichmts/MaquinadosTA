<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSolicitudesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('solicitudes', function (Blueprint $table) {
            $table->id();
            $table->string('tipo'); // modificacion, retrabajo, rechazo, etc
            $table->text('comentarios');
            $table->string('area_solicitante')->nullable();
            $table->integer('usuario_id');
            $table->integer('componente_id');
            $table->integer('fabricacion_id')->nullable();
            $table->boolean('atendida')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('solicitudes');
    }
}
