<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anio extends Model
{
        protected $fillable = ['nombre'];
}
