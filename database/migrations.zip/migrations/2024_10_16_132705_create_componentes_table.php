<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateComponentesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('componentes', function (Blueprint $table) {

            $table->id();
            $table->string('nombre');
            $table->string('archivo_2d')->nullable();
            $table->string('archivo_3d')->nullable();
            // $table->string('archivo_explosionado')->nullable();
            $table->integer('cantidad')->nullable();
            $table->string('otro_material')->nullable();
            $table->string('proveedor')->nullable();
            $table->text('descripcion')->nullable();
            $table->string('largo')->nullable();
            $table->string('ancho')->nullable();
            $table->string('espesor')->nullable();
            $table->string('longitud')->nullable();
            $table->string('diametro')->nullable();
            $table->string('peso')->nullable();
            $table->string('precio_kilo')->nullable();
            $table->text('cuotas_criticas')->nullable(); //json
            $table->text('cuotas_criticas_reales')->nullable(); //json
            
            $table->string('fecha_cargado')->nullable();
            $table->string('fecha_terminado')->nullable();
            $table->string('fecha_programado')->nullable();
            $table->string('fecha_ensamblado')->nullable();
            
            // compras
            $table->string('fecha_solicitud')->nullable();
            $table->string('fecha_pedido')->nullable();
            $table->string('fecha_estimada')->nullable();
            $table->string('fecha_real')->nullable();
            $table->integer('cantidad_reutilizable')->nullable();
            $table->integer('reusados')->nullable();

            // temple
            $table->boolean('requiere_temple')->nullable();
            
            $table->string('fecha_solicitud_temple')->nullable();
            $table->string('fecha_envio_temple')->nullable();
            $table->string('fecha_estimada_temple')->nullable();
            $table->string('fecha_recibido_temple')->nullable();
            $table->string('foto_matricero')->nullable();
            
            // enrutamiento
            $table->string('prioridad')->nullable();
            $table->text('ruta')->nullable();
            
            // programacion
            $table->string('maquina')->nullable();
            $table->text('descripcion_trabajo')->nullable();
            $table->text('herramientas_corte')->nullable();
            
            $table->boolean('refabricado')->nullable();
            $table->integer('version')->nullable();
            
            $table->boolean('es_compra')->nullable();
            $table->decimal('costo_unitario', 12, 2)->nullable();
            
            $table->string('area')->nullable();          
            
            $table->boolean('cargado')->nullable();
            $table->boolean('comprado')->nullable();
            $table->boolean('programado')->nullable();
            $table->boolean('cortado')->nullable();
            $table->boolean('enrutado')->nullable();
            $table->boolean('ensamblado')->nullable();
            
            $table->text('retraso_corte')->nullable(); 
            $table->text('retraso_programacion')->nullable(); 
            
            $table->string('estatus_corte')->nullable(); // inicial, proceso, pausado, finalizado
            $table->string('estatus_programacion')->nullable(); // inicial, proceso, pausado, finalizado
            $table->integer('estatus_fabricacion')->nullable();  // el orden actual en el que va cada fabricacion
            
            $table->boolean('cancelado')->nullable();
            
            $table->integer('matricero_id')->nullable();
            $table->integer('programador_id')->nullable();
            $table->integer('herramental_id')->nullable();
            $table->integer('material_id')->nullable();

            $table->boolean('refaccion')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('componentes');
    }
}
